import Sessions from "@/components/Sessions";

const Session = () => {
  return <Sessions />;
};

export default Session;
